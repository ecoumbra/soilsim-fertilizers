import {useMemo, useState} from 'react';
import {CartesianGrid, Legend, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis} from 'recharts';
import {TEX, Texture, frostDepth, phiOf} from './physics';
import {Soil, downloadXlsx, runSim} from './simulation';
import {col} from './temperatureScale';

const f1 = (v: number, d = 1) => v.toFixed(d).replace('.', ',');
const hh = (h: number) => { const m = Math.round(h * 60) % 1440; return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`; };
const MON = ['Січ', 'Лют', 'Бер', 'Кві', 'Тра', 'Чер', 'Лип', 'Сер', 'Вер', 'Жов', 'Лис', 'Гру'];
const mk = (tex: Texture, th: number, rb: number): Soil => ({tex, th, rb, q: TEX[tex].q});
const SCEN: [string, Soil, Soil][] = [
  ['Пісок проти глини', mk('sand', 0.2, 1500), mk('clay', 0.2, 1200)],
  ['Сухий ґрунт проти вологого', mk('loam', 0.08, 1350), mk('loam', 0.35, 1350)],
  ['Розпушений проти ущільненого', mk('loam', 0.25, 1100), mk('loam', 0.25, 1650)],
];
const COLS = ['#D96B35', '#B8923A', '#6B8E5A', '#3E7C8F', '#244B3B'];

const Sl = (p: {l: string; v: number; min: number; max: number; step: number; fmt: string; on: (v: number) => void}) =>
  <div className="ctl"><label>{p.l}<b>{p.fmt}</b></label><input type="range" min={p.min} max={p.max} step={p.step} value={p.v} onChange={e => p.on(+e.target.value)}/></div>;

function SoilCard(p: {title: string; s: Soil; on: (s: Soil) => void}) {
  const {s} = p, phi = phiOf(s.rb), th = Math.min(s.th, phi - 0.02);
  return <section className="card"><h3>{p.title}</h3>
    <div className="ctl"><label>Гранулометричний клас</label><div className="seg">
      {(Object.keys(TEX) as Texture[]).map(t => <button key={t} className={s.tex === t ? 'on' : ''} onClick={() => p.on({...s, tex: t, rb: TEX[t].rb, q: TEX[t].q})}>{TEX[t].n}</button>)}</div></div>
    <Sl l="Частка кварцу" v={s.q * 100} min={0} max={100} step={5} fmt={`${Math.round(s.q * 100)} %`} on={v => p.on({...s, q: v / 100})}/>
    <Sl l="Вологість θ" v={th} min={0.02} max={+(phi - 0.02).toFixed(2)} step={0.01} fmt={`${Math.round(th * 100)} %`} on={v => p.on({...s, th: v})}/>
    <Sl l="Щільність ρb" v={s.rb} min={1000} max={1800} step={50} fmt={`${f1(s.rb / 1000, 2)} г/см³`} on={v => p.on({...s, rb: v})}/>
    <small>Пористість {Math.round(phi * 100)} %. Профіль: однорідний.</small></section>;
}

export default function Compare() {
  const [e, setE] = useState({mode: 'd' as 'd' | 'y', tm: 20, am: 10, ty: 9, ay: 12, cv: 0});
  const [A, setA] = useState(SCEN[0][1]), [B, setB] = useState(SCEN[0][2]);
  const [pos, setPos] = useState(12), [zi, setZi] = useState(2);
  const D = e.mode === 'd', tm = D ? e.tm : e.ty, a0 = (D ? e.am : e.ay) * (1 - e.cv);
  const ext = useMemo(() => ({mode: e.mode, tm, a0}), [e.mode, tm, a0]);
  const sa = useMemo(() => runSim(A, ext), [A, ext]), sb = useMemo(() => runSim(B, ext), [B, ext]);
  const k = D ? Math.round(pos * 4) % 96 : Math.round(pos), dz = sa.dzcm, maxD = D ? 50 : 300;
  const depths = D ? [0, 5, 10, 20, 50] : [0, 10, 50, 100, 200], at = (P: Float64Array, z: number) => P[Math.round(z / dz)];
  const nz = Math.round(maxD / dz), Pa = sa.prof[k], Pb = sb.prof[k];
  const env = (pr: Float64Array[], i: number) => { let mx = -1e9, mn = 1e9; for (const p of pr) { mx = Math.max(mx, p[i]); mn = Math.min(mn, p[i]); } return [+mx.toFixed(2), +mn.toFixed(2)]; };
  const profile = Array.from({length: nz + 1}, (_, i) => { const [am, an] = env(sa.prof, i), [bm, bn] = env(sb.prof, i); return {z: +(i * dz).toFixed(1), a: +Pa[i].toFixed(2), b: +Pb[i].toFixed(2), am, an, bm, bn}; });
  const i10 = Math.round(10 / dz), amp = (sim: typeof sa) => { const [mx, mn] = env(sim.prof, i10); return (mx - mn) / 2; };
  const tmax = (sim: typeof sa) => { let b = 0; sim.prof.forEach((p, i) => { if (p[i10] > sim.prof[b][i10]) b = i; }); return D ? b / 4 : b; };
  const series = sa.prof.map((p, i) => {
    const row: Record<string, number> = {x: D ? i / 4 : i};
    depths.forEach(z => { const a = at(p, z), b = at(sb.prof[i], z); row['a' + z] = +a.toFixed(2); row['b' + z] = +b.toFixed(2); row['d' + z] = +(a - b).toFixed(2); });
    return row;
  });
  const fa = Math.max(...sa.prof.map(p => frostDepth(p, dz))), fb = Math.max(...sb.prof.map(p => frostDepth(p, dz)));
  const rows: [string, number, number, number][] = [
    ['Теплопровідність λ, Вт/(м·К)', sa.u.lam, sb.u.lam, 2], ['Теплоємність Cv, МДж/(м³·К)', sa.u.cv / 1e6, sb.u.cv / 1e6, 2],
    ['Температуропровідність α, мм²/с', sa.u.alpha * 1e6, sb.u.alpha * 1e6, 3], [`Глибина проникнення d (${D ? 'доба' : 'рік'}), см`, sa.d * 100, sb.d * 100, 1],
    ['Температура поверхні, °C', Pa[0], Pb[0], 1], ['Температура на 10 см, °C', at(Pa, 10), at(Pb, 10), 1], ['Температура на 20 см, °C', at(Pa, 20), at(Pb, 20), 1],
    ['Амплітуда на 10 см, °C', amp(sa), amp(sb), 2], [`Час максимуму на 10 см, ${D ? 'год' : 'день року'}`, tmax(sa), tmax(sb), D ? 2 : 0],
    ['Максимальна глибина промерзання, см', fa, fb, 0],
  ];
  const lo = Math.floor(tm - a0 - 1), hi = Math.ceil(tm + a0 + 1), xf = (v: number) => D ? (v >= 24 ? '24:00' : hh(v)) : MON[Math.min(11, Math.floor(v / 30.5))];
  const xt = D ? [0, 6, 12, 18, 24] : [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  const lg = {verticalAlign: 'top' as const, iconType: 'plainline' as const, iconSize: 18, wrapperStyle: {fontSize: 12, paddingBottom: 6}};
  const set = (p: Partial<typeof e>) => setE(o => ({...o, ...p}));
  const exportXlsx = () => downloadXlsx(`soilsim_porivnyannya_${e.mode}.xlsx`, [
    {name: 'Параметри', rows: [['Параметр', 'Значення'], ['Режим', D ? 'добовий' : 'річний'], ['Дата експорту', new Date().toISOString()], ['Середня температура, °C', tm], ['Амплітуда з урахуванням вкриття, °C', +a0.toFixed(2)],
      ['Проективне вкриття, %', Math.round(e.cv * 100)], ['Позиція часу', D ? hh(pos) : `день ${Math.round(pos) + 1}`], ['Граничні умови', 'Діріхле: T поверхні = Tсер + A0·cos(...); T низу = Tсер; профіль однорідний'], [],
      ['Ґрунт', 'А', 'Б'], ['Клас', TEX[A.tex].n, TEX[B.tex].n], ['Вологість θ, м³/м³', A.th, B.th], ['Щільність ρb, кг/м³', A.rb, B.rb], ['Частка кварцу', A.q, B.q]]},
    {name: 'Показники', rows: [['Показник', 'Ґрунт А', 'Ґрунт Б', '|А−Б|'], ...rows.map(r => [r[0], +r[1].toFixed(r[3] + 1), +r[2].toFixed(r[3] + 1), +Math.abs(r[1] - r[2]).toFixed(r[3] + 1)])]},
    {name: 'Профіль', rows: [['Глибина, см', 'T А, °C', 'T Б, °C', 'ΔT, °C'], ...profile.map(p => [p.z, p.a, p.b, +(p.a - p.b).toFixed(2)])]},
    {name: D ? 'Добова динаміка' : 'Річна динаміка', rows: [[D ? 'Година' : 'День', ...depths.flatMap(z => [`А ${z} см`, `Б ${z} см`, `ΔT ${z} см`])], ...series.map(r => [r.x, ...depths.flatMap(z => [r['a' + z], r['b' + z], r['d' + z]])])]},
  ]);

  return <>
    <section className="card"><h3>Сценарії та спільні зовнішні умови</h3>
      <div className="seg">{SCEN.map(([n, a, b]) => <button key={n} onClick={() => { setA(a); setB(b); }}>{n}</button>)}
        {([['d', 'Добовий'], ['y', 'Річний']] as const).map(([m, n]) => <button key={m} className={e.mode === m ? 'on' : ''} onClick={() => { set({mode: m}); setPos(m === 'd' ? 12 : 200); }}>{n} режим</button>)}
        <button onClick={exportXlsx}>⬇ Excel: порівняння</button></div>
      <div className="two" style={{marginTop: 12}}>
        {D ? <><Sl l="Середня температура" v={e.tm} min={-10} max={35} step={1} fmt={`${e.tm} °C`} on={v => set({tm: v})}/><Sl l="Добова амплітуда" v={e.am} min={2} max={20} step={1} fmt={`${e.am} °C`} on={v => set({am: v})}/></>
          : <><Sl l="Середньорічна температура" v={e.ty} min={-4} max={18} step={1} fmt={`${e.ty} °C`} on={v => set({ty: v})}/><Sl l="Річна амплітуда" v={e.ay} min={6} max={28} step={1} fmt={`${e.ay} °C`} on={v => set({ay: v})}/></>}
        <Sl l="Проективне вкриття (обом ґрунтам)" v={e.cv * 100} min={0} max={90} step={5} fmt={`${Math.round(e.cv * 100)} %`} on={v => set({cv: v / 100})}/>
        <Sl l={D ? 'Час доби' : 'День року'} v={pos} min={0} max={D ? 23.75 : 365} step={D ? 0.25 : 1} fmt={D ? hh(pos) : `${MON[Math.min(11, Math.floor(pos / 30.5))]}, ${Math.round(pos) + 1}`} on={setPos}/></div></section>
    <div className="two" style={{marginTop: 16}}><SoilCard title="Ґрунт А" s={A} on={setA}/><SoilCard title="Ґрунт Б" s={B} on={setB}/></div>

    <div className="two" style={{marginTop: 16}}>
      <section className="card"><h3>Температурні профілі (однакова шкала)</h3>
        <svg viewBox="0 0 320 340" role="img" aria-label="Профілі А і Б">
          {[['А', 40, Pa], ['Б', 190, Pb]].map(([n, x0, P]) => <g key={n as string}>
            {Array.from({length: nz}, (_, i) => <rect key={i} x={x0 as number} y={20 + i * 300 / nz} width={100} height={300 / nz + 0.7} fill={col(((P as Float64Array)[i] + (P as Float64Array)[i + 1]) / 2)}><title>{`${f1(i * dz)} см: ${f1((P as Float64Array)[i])} °C`}</title></rect>)}
            <rect x={x0 as number} y={20} width={100} height={300} fill="none" stroke="#8D7055" strokeWidth={2}/><text x={(x0 as number) + 50} y={14} textAnchor="middle" fontSize={12} fontWeight={700}>Ґрунт {n as string}</text></g>)}
          {[0, 0.25, 0.5, 1].map(f => <text key={f} x={34} y={24 + f * 300} textAnchor="end" fontSize={11}>{Math.round(f * maxD)} см</text>)}
        </svg><p className="note">Кольори обох профілів — з однієї шкали температур; наведіть курсор на шар для значення.</p></section>
      <section className="card"><h3>Показники</h3>
        <table className="t"><thead><tr><th>Показник</th><th>А</th><th>Б</th><th>|А−Б|</th></tr></thead><tbody>
          {rows.map(r => <tr key={r[0]}><td>{r[0]}</td><td>{f1(r[1], r[3])}</td><td>{f1(r[2], r[3])}</td><td>{f1(Math.abs(r[1] - r[2]), r[3])}</td></tr>)}</tbody></table>
        <p className="note">Поверхня задана однаково, тому відмінності проявляються з глибиною: у меншій амплітуді та пізнішому максимумі. Результат слід інтерпретувати залежно від досліджуваної властивості: тут немає «кращого» чи «гіршого» ґрунту.</p></section></div>

    <div className="charts">
      <section className="card"><h3>Температура за глибиною: А і Б</h3>
        <ResponsiveContainer width="100%" height={340}><LineChart data={profile} layout="vertical" margin={{left: 8, right: 16, bottom: 10}}>
          <CartesianGrid stroke="#D9D3C5"/><XAxis type="number" domain={[lo, hi]} allowDataOverflow tickCount={7} height={50} label={{value: 'Температура, °C', position: 'insideBottom', offset: 0}}/>
          <YAxis type="number" dataKey="z" domain={[0, maxD]} label={{value: 'Глибина, см', angle: -90, position: 'insideLeft'}}/>
          <Tooltip formatter={(v: number) => `${f1(v)} °C`} labelFormatter={z => `${z} см`}/><Legend {...lg}/>
          <Line dataKey="a" name="Ґрунт А (зараз)" stroke="#D96B35" strokeWidth={2.5} dot={false} isAnimationActive={false}/><Line dataKey="am" name="А: макс./мін. за цикл" stroke="#D96B35" strokeWidth={1.5} strokeDasharray="5 3" dot={false} isAnimationActive={false}/><Line dataKey="an" legendType="none" stroke="#D96B35" strokeWidth={1.5} strokeDasharray="5 3" dot={false} isAnimationActive={false}/>
          <Line dataKey="b" name="Ґрунт Б (зараз)" stroke="#3E7C8F" strokeWidth={2.5} dot={false} isAnimationActive={false}/><Line dataKey="bm" name="Б: макс./мін. за цикл" stroke="#3E7C8F" strokeWidth={1.5} strokeDasharray="5 3" dot={false} isAnimationActive={false}/><Line dataKey="bn" legendType="none" stroke="#3E7C8F" strokeWidth={1.5} strokeDasharray="5 3" dot={false} isAnimationActive={false}/></LineChart></ResponsiveContainer></section>
      <section className="card"><h3>{D ? 'Добова' : 'Річна'} динаміка на глибині {depths[zi]} см</h3>
        <div className="seg" style={{marginBottom: 8}}>{depths.map((z, i) => <button key={z} className={zi === i ? 'on' : ''} onClick={() => setZi(i)}>{z ? `${z} см` : 'Поверхня'}</button>)}</div>
        <ResponsiveContainer width="100%" height={300}><LineChart data={series} margin={{left: 0, right: 16}}>
          <CartesianGrid stroke="#D9D3C5"/><XAxis dataKey="x" type="number" domain={[0, D ? 24 : 365]} ticks={xt} tickFormatter={xf}/><YAxis domain={[lo, hi]} allowDataOverflow unit="°"/>
          <Tooltip labelFormatter={v => xf(+v)} formatter={(v: number) => `${f1(v)} °C`}/><Legend {...lg}/><ReferenceLine x={D ? pos : Math.round(pos)} stroke="#28332D" strokeDasharray="4 4"/>
          <Line dataKey="a0" name="Поверхня (однакова)" stroke="#9aa39d" strokeWidth={1.5} strokeDasharray="2 3" dot={false} isAnimationActive={false}/>
          <Line dataKey={'a' + depths[zi]} name={`Ґрунт А, ${depths[zi]} см`} stroke="#D96B35" strokeWidth={3} dot={false} isAnimationActive={false}/>
          <Line dataKey={'b' + depths[zi]} name={`Ґрунт Б, ${depths[zi]} см`} stroke="#3E7C8F" strokeWidth={3} dot={false} isAnimationActive={false}/></LineChart></ResponsiveContainer></section>
      <section className="card"><h3>Різниця температур ΔT = T_A − T_Б</h3>
        <ResponsiveContainer width="100%" height={300}><LineChart data={series} margin={{left: 0, right: 16}}>
          <CartesianGrid stroke="#D9D3C5"/><XAxis dataKey="x" type="number" domain={[0, D ? 24 : 365]} ticks={xt} tickFormatter={xf}/><YAxis unit="°"/><ReferenceLine y={0} stroke="#28332D"/>
          <Tooltip labelFormatter={v => xf(+v)} formatter={(v: number) => `${f1(v)} °C`}/><Legend {...lg}/><ReferenceLine x={D ? pos : Math.round(pos)} stroke="#28332D" strokeDasharray="4 4"/>
          {depths.map((z, i) => <Line key={z} dataKey={'d' + z} name={`${z} см`} stroke={COLS[i]} strokeWidth={2} dot={false} isAnimationActive={false}/>)}</LineChart></ResponsiveContainer></section>
    </div>
    <p className="note">Обидва ґрунти розраховуються одним ядром (physics.ts) за однакових граничних умов; змінюються лише параметри ґрунту. Профіль однорідний, граничні умови — Діріхле (див. docs/).</p>
  </>;
}
