// Єдина колірна шкала температур (однакова для всіх модулів).
const STOPS: [number, number[]][] = [[-15, [70, 120, 175]], [0, [130, 185, 220]], [10, [190, 215, 222]], [20, [246, 231, 168]], [30, [232, 150, 70]], [40, [217, 107, 53]], [50, [179, 38, 30]]];
export const col = (t: number) => {
  if (t <= STOPS[0][0]) return `rgb(${STOPS[0][1]})`;
  for (let i = 1; i < STOPS.length; i++) if (t <= STOPS[i][0]) {
    const [t0, c0] = STOPS[i - 1], [t1, c1] = STOPS[i], u = (t - t0) / (t1 - t0);
    return `rgb(${c0.map((c, j) => Math.round(c + (c1[j] - c) * u))})`;
  }
  return `rgb(${STOPS[STOPS.length - 1][1]})`;
};
