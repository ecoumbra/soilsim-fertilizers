// Теплофізика ґрунту та 1D теплоперенос. Документація: docs/MATHEMATICAL_MODEL.md
export type Texture = 'sand' | 'loam' | 'clay';
/** q — типова частка кварцу (значення за замовчуванням; можна задавати незалежно), coarse — вибір емпіричної кривої Ke. */
export const TEX: Record<Texture, {n: string; q: number; rb: number; coarse: boolean}> = {
  sand: {n: 'Пісок', q: 0.8, rb: 1500, coarse: true},
  loam: {n: 'Суглинок', q: 0.4, rb: 1350, coarse: false},
  clay: {n: 'Глина', q: 0.2, rb: 1200, coarse: false},
};
export const W = 2 * Math.PI / 86400, T_MAX_H = 14, DAY_MAX = 200;
export const RHO_S = 2650;          // щільність твердої фази за замовчуванням, кг/м³
export const LV = 3.34e8;           // об'ємна теплота плавлення води, Дж/м³ (ρw·Lf = 1000·3.34e5)
export const DTF = 1;               // ширина інтервалу замерзання за замовчуванням, К

export const phiOf = (rb: number, rs = RHO_S) => 1 - rb / rs;
export interface SoilOpt {q?: number; rs?: number}
export type Props = ReturnType<typeof soilProps>;

/** λ, Cv, α за Johansen (1975) та адитивним правилом Cv=(1−n)Cs+θCw (газова фаза знехтувана). Кидає RangeError для недопустимих ρb. */
export function soilProps(t: Texture, theta: number, rb: number, frozen = false, o: SoilOpt = {}) {
  const s = TEX[t], rs = o.rs ?? RHO_S, q = Math.min(1, Math.max(0, o.q ?? s.q)), phi = phiOf(rb, rs);
  if (!(phi > 0 && phi < 1)) throw new RangeError('ρb має бути в межах (0, ρs)');
  const th = Math.min(Math.max(theta, 0), phi * 0.99);               // θ ≤ пористість
  const cv = (1 - phi) * 2.0e6 + th * (frozen ? 1.93e6 : 4.18e6);
  const ls = 7.7 ** q * 2.0 ** (1 - q), dry = (0.135 * rb + 64.7) / (2700 - 0.947 * rb);
  const sat = ls ** (1 - phi) * (frozen ? 2.2 : 0.57) ** phi, sr = th / phi;
  const ke = frozen ? sr : sr < (s.coarse ? 0.05 : 0.1) ? 0 : Math.min(1, Math.max(0, (s.coarse ? 0.7 : 1) * Math.log10(sr) + 1));
  const lam = (sat - dry) * ke + dry;
  return {lam, cv, alpha: lam / cv, th, phi};
}

/** Частка льоду: гладка (C¹) функція smoothstep на інтервалі [−dT, 0]. */
export const iceFraction = (T: number, dT = DTF) => { const x = Math.min(1, Math.max(0, -T / dT)); return x * x * (3 - 2 * x); };
/** λ і ефективна Cv = Cv_sens + Lv·dθ_i/d(−T): без стрибків на межах інтервалу. */
export function phaseProps(L: {u: Props; f: Props}, T: number, dT = DTF) {
  const fi = iceFraction(T, dT), x = Math.min(1, Math.max(0, -T / dT));
  return {lam: (1 - fi) * L.u.lam + fi * L.f.lam, cv: (1 - fi) * L.u.cv + fi * L.f.cv + LV * L.u.th * 6 * x * (1 - x) / dT};
}

export const dampDepth = (alpha: number, period = 86400) => Math.sqrt(alpha * period / Math.PI);
export const analytic = (tm: number, a0: number, alpha: number, zcm: number, h: number) => {
  const k = zcm / 100 / dampDepth(alpha);
  return tm + a0 * Math.exp(-k) * Math.cos(W * (h - T_MAX_H) * 3600 - k);
};

export interface SolveOpt {
  n: number; dz: number; dt: number; steps: number; from: number; every: number; tb: number;
  /** Діріхле: задана температура поверхні. Ігнорується, якщо задано surface. */
  ts?: (t: number) => number;
  /** Потік через поверхневий опір R (м²·К/Вт): q=(Tповітря−T0)/R. Не змішується з ts. */
  surface?: {tair: (t: number) => number; R: number};
  prop: (i: number, T: number) => {lam: number; cv: number};
}
/** Неявна схема + Томас; вузол 0 — поверхня (півкомірка при surface), нижній вузол — Діріхле Tb. λ на межах — гармонічне середнє. */
export function solve(o: SolveOpt) {
  const {n, dz, dt} = o, out: Float64Array[] = [];
  let T = new Float64Array(n).fill(o.tb);
  const a = new Float64Array(n), b = new Float64Array(n), c = new Float64Array(n), r = new Float64Array(n), lam = new Float64Array(n), cv = new Float64Array(n);
  const hm = (i: number) => 2 * lam[i] * lam[i + 1] / (lam[i] + lam[i + 1]);
  for (let s = 1; s <= o.steps; s++) {
    const t = s * dt;
    for (let i = 0; i < n; i++) { const p = o.prop(i, T[i]); lam[i] = p.lam; cv[i] = p.cv; }
    if (o.surface && o.surface.R > 0) {
      const k = dt / (cv[0] * dz / 2), le = hm(0);
      b[0] = 1 + k * (le / dz + 1 / o.surface.R); c[0] = -k * le / dz; r[0] = T[0] + k * o.surface.tair(t) / o.surface.R;
    } else { b[0] = 1; c[0] = 0; r[0] = o.surface ? o.surface.tair(t) : o.ts!(t); }
    b[n - 1] = 1; a[n - 1] = 0; r[n - 1] = o.tb;
    for (let i = 1; i < n - 1; i++) {
      const lw = hm(i - 1), le = hm(i), k = dt / (cv[i] * dz * dz);
      a[i] = -k * lw; c[i] = -k * le; b[i] = 1 + k * (lw + le); r[i] = T[i];
    }
    for (let i = 1; i < n; i++) { const m = a[i] / b[i - 1]; b[i] -= m * c[i - 1]; r[i] -= m * r[i - 1]; }
    const x = new Float64Array(n); x[n - 1] = r[n - 1] / b[n - 1];
    for (let i = n - 2; i >= 0; i--) x[i] = (r[i] - c[i] * x[i + 1]) / b[i];
    T = x;
    if (s >= o.from && (s - o.from) % o.every === 0) out.push(T);
  }
  return out;
}
/** Глибина промерзання, см: 0 ≤ значення ≤ (n−1)·dz. */
export const frostDepth = (T: Float64Array, dzcm: number) => {
  if (T[0] >= 0) return 0;
  for (let i = 1; i < T.length; i++) if (T[i] >= 0) return (i - 1 + T[i - 1] / (T[i - 1] - T[i])) * dzcm;
  return (T.length - 1) * dzcm;
};

/** Контрольний тест (dt має ділити 900 с): E_max = max|T_num − T_analytic| у 0–50 см для однорідного ґрунту без замерзання. */
export function harmonicError(p: {alpha: number; tm?: number; a0?: number; n?: number; dz?: number; dt?: number; days?: number}) {
  const {alpha, tm = 15, a0 = 10, n = 101, dz = 0.01, dt = 300, days = 6} = p, cv = 2e6, lam = alpha * cv;
  const prof = solve({n, dz, dt, steps: days * 86400 / dt, from: (days - 1) * 86400 / dt, every: Math.round(900 / dt), tb: tm,
    ts: t => tm + a0 * Math.cos(2 * Math.PI * (t / 3600 - T_MAX_H) / 24), prop: () => ({lam, cv})});
  let e = 0;
  prof.forEach((P, k) => { for (let i = 0; i < n && i * dz <= 0.5 + 1e-9; i++) e = Math.max(e, Math.abs(P[i] - analytic(tm, a0, alpha, i * dz * 100, k / 4))); });
  return e;
}
