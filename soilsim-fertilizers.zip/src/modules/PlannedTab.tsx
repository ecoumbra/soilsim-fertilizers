import { useI18n } from '../i18n';
import { ModelBadge, type ModelType } from '../components/ui/Badges';

export interface PlannedItem { id: string; badge?: ModelType; stage: number }

/** Чесний стан для ще не реалізованих вкладок: список запланованого, без кнопок-муляжів. */
export function PlannedTab({ items }: { items: PlannedItem[] }) {
  const { t } = useI18n();
  return (
    <section className="fade-in rounded-xl border border-border bg-card p-6 shadow-soft">
      <h2 className="text-xl font-semibold">{t('planned.title')}</h2>
      <p className="mt-1 text-sm text-muted-foreground">{t('planned.text')}</p>
      <ul className="mt-4 grid gap-2 sm:grid-cols-2">
        {items.map((it) => (
          <li key={it.id} className="flex items-center justify-between gap-2 rounded-lg border border-border bg-background px-3 py-2">
            <span className="text-sm font-medium">{t(`planned.${it.id}`)}</span>
            <span className="flex items-center gap-2">
              {it.badge && <ModelBadge type={it.badge} />}
              <span className="text-xs text-muted-foreground">{t('planned.stage', { n: it.stage })}</span>
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}
