import { useI18n } from '../../i18n';
import { useHashRoute } from '../../hooks/useHashRoute';
import { PillNav } from '../../components/ui/Controls';
import { PlannedTab } from '../PlannedTab';
import MixingTable from './MixingTable';

const SUBS = ['mixing', 'solubility', 'phosphate', 'column'] as const;
type Sub = (typeof SUBS)[number];

const PLANNED: Record<Exclude<Sub, 'mixing'>, { id: string; badge: 'calc' | 'approx' | 'concept'; stage: number }[]> = {
  solubility: [{ id: 'lab.solubility', badge: 'approx', stage: 6 }],
  phosphate: [{ id: 'lab.phosphate', badge: 'calc', stage: 6 }],
  column: [{ id: 'lab.column', badge: 'concept', stage: 7 }],
};

export default function LabTab() {
  const { t } = useI18n();
  const { parts, navigate } = useHashRoute();
  const sub: Sub = (SUBS as readonly string[]).includes(parts[1]) ? (parts[1] as Sub) : 'mixing';
  return (
    <div className="space-y-5">
      <PillNav label="lab" active={sub} onSelect={(id) => navigate('lab', id)} items={SUBS.map((s) => ({ id: s, label: t(`sub.${s}`) }))} />
      {sub === 'mixing' ? <MixingTable /> : <PlannedTab items={PLANNED[sub]} />}
    </div>
  );
}
