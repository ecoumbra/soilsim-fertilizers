import {describe, expect, it} from 'vitest';
import {TEX, Texture, analytic, dampDepth, frostDepth, harmonicError, phaseProps, phiOf, soilProps, solve} from './physics';

const TEXS = Object.keys(TEX) as Texture[];
describe('теплофізика ґрунту', () => {
  it('пористість у фізичних межах', () => { for (const rb of [1000, 1350, 1800]) { const n = phiOf(rb); expect(n).toBeGreaterThan(0); expect(n).toBeLessThan(1); } });
  it('недопустима щільність викликає помилку', () => { expect(() => soilProps('loam', 0.2, 2700)).toThrow(RangeError); });
  it('вологість не перевищує пористість, λ і Cv додатні, α = λ/Cv', () => {
    for (const t of TEXS) for (const th of [0, 0.1, 0.3, 0.9]) for (const rb of [1000, 1400, 1800]) for (const fr of [false, true]) {
      const p = soilProps(t, th, rb, fr);
      expect(p.th).toBeLessThanOrEqual(p.phi); expect(p.lam).toBeGreaterThan(0); expect(p.cv).toBeGreaterThan(0);
      expect(p.alpha).toBeCloseTo(p.lam / p.cv, 15);
    }
  });
  it('кварц задається незалежно від класу', () => { expect(soilProps('loam', 0.2, 1350, false, {q: 0.9}).lam).toBeGreaterThan(soilProps('loam', 0.2, 1350, false, {q: 0.1}).lam); });
  it('глибина проникнення зростає з α і періодом', () => {
    expect(dampDepth(1e-6)).toBeGreaterThan(dampDepth(5e-7)); expect(dampDepth(5e-7, 365 * 86400)).toBeGreaterThan(dampDepth(5e-7));
  });
});

describe('чисельна модель', () => {
  it('збігається з гармонічним розв\'язком; похибка спадає з dt і dz', () => {
    const e = harmonicError({alpha: 0.5e-6});
    expect(e).toBeLessThan(0.06);                                    // поріг обрано за результатами VALIDATION.md (≈0,039 при A0=10 °C)
    expect(harmonicError({alpha: 0.5e-6, dt: 150})).toBeLessThan(e);
    expect(harmonicError({alpha: 0.5e-6, dz: 0.005, n: 201})).toBeLessThan(e);
  });
  it('нижня межа достатньо віддалена: 1 м і 2 м дають близький результат', () => {
    expect(Math.abs(harmonicError({alpha: 0.5e-6, n: 201}) - harmonicError({alpha: 0.5e-6}))).toBeLessThan(0.01);
  });
  it('Cv_eff неперервна: немає стрибка на межах інтервалу замерзання', () => {
    const L = {u: soilProps('loam', 0.25, 1350), f: soilProps('loam', 0.25, 1350, true)};
    let prev = phaseProps(L, 2).cv, jump = 0;
    for (let T = 2; T > -3; T -= 0.001) { const c = phaseProps(L, T).cv; jump = Math.max(jump, Math.abs(c - prev)); prev = c; }
    expect(jump).toBeLessThan(6e5);                                  // ≈ max|d²Cv/dT²|·0,001 К = 5e5 Дж/(м³·К)
  });
  it('промерзання: 0 ≤ глибина ≤ глибина профілю', () => {
    const L = {u: soilProps('loam', 0.3, 1350), f: soilProps('loam', 0.3, 1350, true)}, n = 81, dz = 0.05;
    const P = solve({n, dz, dt: 21600, steps: 5840, from: 4380, every: 4, tb: 0, prop: (_i, T) => phaseProps(L, T), ts: t => 12 * Math.cos(2 * Math.PI * (t / 86400 - 200) / 365)});
    const fd = P.map(x => frostDepth(x, dz * 100));
    expect(Math.min(...fd)).toBeGreaterThanOrEqual(0); expect(Math.max(...fd)).toBeLessThanOrEqual((n - 1) * dz * 100); expect(Math.max(...fd)).toBeGreaterThan(0);
  });
  it('двошаровий профіль: неперервність температури і потоку через межу', () => {
    const n = 101, dz = 0.01, b = 30, l1 = 1, l2 = 2, cv = 2e6, ts = 10, tb = 0;
    const T = solve({n, dz, dt: 3600, steps: 3000, from: 3000, every: 1, tb, ts: () => ts, prop: i => ({lam: i < b ? l1 : l2, cv})})[0];
    const h1 = (b - 0.5) * dz, h2 = (n - 1 - b + 0.5) * dz, q = (ts - tb) / (h1 / l1 + h2 / l2);   // межа шарів — на грані комірок, (b−½)·dz
    expect(l1 * (T[b - 2] - T[b - 1]) / dz).toBeCloseTo(q, 6); expect(l2 * (T[b] - T[b + 1]) / dz).toBeCloseTo(q, 6);
    expect(Math.abs(T[b] - T[b - 1]) / dz).toBeLessThan(10 * q / l1);   // без штучного стрибка
  });
  it('поверхневий опір R→0 відтворює умову Діріхле', () => {
    const ts = (t: number) => 10 + 8 * Math.cos(2 * Math.PI * t / 86400), prop = () => ({lam: 1.1, cv: 2.1e6}), o = {n: 101, dz: 0.01, dt: 300, steps: 864, from: 864, every: 1, tb: 10, prop};
    const A = solve({...o, ts})[0], B = solve({...o, surface: {tair: ts, R: 1e-9}})[0];
    expect(Math.max(...A.map((v, i) => Math.abs(v - B[i])))).toBeLessThan(1e-4);
  });
  it('енергетичний баланс: ΔЗапас = ∫(Ft − Fb)dt для сталих властивостей', () => {
    const dt = 600, N = 61, dz = 0.02, R = 0.4, lam = 1.2, cv = 2e6, tair = (t: number) => -5 + 10 * Math.sin(t / 20000);
    const P = solve({n: N, dz, dt, steps: 100, from: 1, every: 1, tb: 3, prop: () => ({lam, cv}), surface: {tair, R}});
    let prev = new Float64Array(N).fill(3), worst = 0;
    P.forEach((x, s) => {
      let dE = 0; for (let i = 0; i < N - 1; i++) dE += cv * (i === 0 ? dz / 2 : dz) * (x[i] - prev[i]);
      worst = Math.max(worst, Math.abs(dE - dt * ((tair((s + 1) * dt) - x[0]) / R - lam * (x[N - 2] - x[N - 1]) / dz))); prev = x;
    });
    expect(worst).toBeLessThan(1e-3);
  });
  it('аналітична функція дає максимум на поверхні о 14:00', () => { expect(analytic(15, 10, 5e-7, 0, 14)).toBeCloseTo(25, 6); });
});
