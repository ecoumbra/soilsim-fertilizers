// Єдиний вхід до розрахунку: параметри ґрунту + зовнішні умови → T(z,t) (одне ядро для всіх модулів).
import {DAY_MAX, Texture, dampDepth, phaseProps, phiOf, solve, soilProps} from './physics';
export interface Soil {tex: Texture; th: number; rb: number; q: number}
export interface Ext {mode: 'd' | 'y'; tm: number; a0: number}
export function runSim(soil: Soil, ext: Ext) {
  const th = Math.min(soil.th, phiOf(soil.rb) - 0.02), o = {q: soil.q};
  const u = soilProps(soil.tex, th, soil.rb, false, o), f = soilProps(soil.tex, th, soil.rb, true, o);
  const D = ext.mode === 'd', {tm, a0} = ext, n = D ? 101 : 81, dz = D ? 0.01 : 0.05, prop = (_i: number, T: number) => phaseProps({u, f}, T);
  const prof = D
    ? solve({n, dz, dt: 300, steps: 1728, from: 1440, every: 3, tb: tm, prop, ts: t => tm + a0 * Math.cos(2 * Math.PI * (t / 3600 - 14) / 24)})
    : solve({n, dz, dt: 21600, steps: 5840, from: 4380, every: 4, tb: tm, prop, ts: t => tm + a0 * Math.cos(2 * Math.PI * (t / 86400 - DAY_MAX) / 365)});
  return {u, dzcm: dz * 100, prof, d: dampDepth(u.alpha, D ? 86400 : 365 * 86400)};
}
export type Cell = string | number;
/** Експорт у .xlsx (SheetJS підвантажується лише при натисканні). Числа записуються як числа. */
export async function downloadXlsx(name: string, sheets: {name: string; rows: Cell[][]}[]) {
  const XLSX = await import('xlsx');
  const wb = XLSX.utils.book_new();
  for (const sh of sheets) {
    const ws = XLSX.utils.aoa_to_sheet(sh.rows), nc = Math.max(...sh.rows.map(r => r.length));
    ws['!cols'] = Array.from({length: nc}, (_, c) => ({wch: Math.min(52, Math.max(11, ...sh.rows.map(r => String(r[c] ?? '').length + 2)))}));
    XLSX.utils.book_append_sheet(wb, ws, sh.name.slice(0, 31));
  }
  XLSX.writeFile(wb, name);
}
