# SOURCES — реєстр джерел

Дата доступу: 2026-11-13. Усі джерела знайдено пошуком у мережі; назви, яких не вдалося підтвердити, позначено примітками. **Не додавалося жодних DOI чи бібліографічних даних, яких не було знайдено.**

Правило статусу «Верифіковано»: значення підтверджене щонайменше одним джерелом (те саме значення або значення в межах діапазону автора) і не суперечить іншим знайденим джерелам. Розбіжності з даними автора пояснено в `AGROCHEMICAL_REVIEW.md`.

## msu-n-sources
- **More on alternative sources of nitrogen (table “Soil reaction of common nitrogen fertilizer sources”, after the Western Fertilizer Handbook)**
- Michigan State University Extension · Extension-служба університету
- https://www.canr.msu.edu/news/more_on_alternative_sources_of_nitrogen
- Використано для: Аміачна селітра, Карбамід (сечовина), Сульфат амонію, Кальцієва селітра, Амофос, Діамонійфосфат (DAP)

## unl-g1503
- **Management Strategies to Reduce the Rate of Soil Acidification (G1503, revised June 2015)**
- University of Nebraska–Lincoln Extension · Extension-служба університету
- https://extensionpubs.unl.edu/publication/g1503/na/pdf/view
- Використано для: Аміачна селітра, Карбамід (сечовина), Сульфат амонію, Безводний аміак, Суперфосфат подвійний, Амофос, Діамонійфосфат (DAP)

## unl-passel-n
- **Nitrogen Fertilizers (PASSEL lesson)**
- University of Nebraska–Lincoln (PASSEL) · Extension-служба університету
- https://passel2.unl.edu/view/lesson/d01bf6ce5f62/1
- Використано для: Карбамід (сечовина), Сульфат амонію, Безводний аміак, КАС, правило сумісності: urea-an-solution

## nsw-dpi-n
- **Don’t let nitrogen acidify your soil**
- NSW Department of Primary Industries (Australia) · Установа
- https://www.dpi.nsw.gov.au/agriculture/soils/guides/soil-acidity/n-acidify
- Використано для: Аміачна селітра, Карбамід (сечовина), Кальцієва селітра

## pmc-urease
- **Review on urease inhibitors (NBPT, NPPT) and ammonia volatilization from urea-based fertilizers**
- PubMed Central, PMC6077139 · Наукова публікація
- https://pmc.ncbi.nlm.nih.gov/articles/PMC6077139
- Використано для: Карбамід (сечовина)
- Примітка: Точну назву й авторів не вдалося отримати (сторінка закрита капчею) — опис змісту за знайденим фрагментом.

## purdue-urea
- **Improving the efficient use of urea-containing fertilizers**
- Purdue University, Agronomy Extension · Extension-служба університету
- https://WWW.AG.PURDUE.EDU/AGRY/agry-extension/_docs/soil-fertility/improving-the-efficient-use-of-urea-containing-fertilizers.pdf
- Використано для: Карбамід (сечовина)

## isu-nh3
- **Anhydrous Ammonia Application in Dry Soil (content author: John Sawyer)**
- Iowa State University Extension and Outreach · Extension-служба університету
- https://crops.extension.iastate.edu/post/anhydrous-ammonia-application-dry-soil
- Використано для: Безводний аміак

## slu-can
- **Study of hygroscopicity and dissolution of calcium ammonium nitrate and ammonium nitrate fertilizers**
- Swedish University of Agricultural Sciences (SLU), Epsilon archive, document 20364486 · Наукова публікація
- https://pub.epsilon.slu.se/id/document/20364486
- Використано для: Аміачна селітра, Кальцієва селітра
- Примітка: Точну назву й видання не вдалося отримати — опис змісту за знайденим фрагментом (розділ «Material and methods», дані Lide 2004).

## nptel-ca-nitrate
- **Lecture 11: Calcium Nitrate (fertilizer technology course)**
- NPTEL (India) · Навчальні матеріали
- https://archive.nptel.ac.in/content/storage2/courses/103107086/module2/lecture8/lecture8.pdf
- Використано для: Кальцієва селітра

## royal-brinkman-ca
- **Calcium nitrate (DUCANIT), product page**
- Royal Brinkman (distributor) · Специфікація виробника/продавця
- https://royalbrinkman.com/crop-care/fertilizers/water-soluble/singular/calcium-nitrate-25kg-bag-1200kg-plt-150011353
- Використано для: Кальцієва селітра, правило сумісності: ca-nitrate-phosphate-solution, правило сумісності: ca-nitrate-sulfate-solution

## uk-forages-uan
- **Forage News, 3 March 2021 (nitrogen sources: urea, UAN, ammonium nitrate)**
- University of Kentucky, Forage Extension · Extension-служба університету
- https://forages.ca.uky.edu/files/3_march_2021_final.pdf
- Використано для: КАС, правило сумісності: urea-an-solution

## uralchem-an
- **Ammonium nitrate — product specification**
- UralChem · Специфікація виробника/продавця
- https://agro.uralchem.com/upload/iblock/24e/tyg47sb2u75ckoig3893sh1e9gtd40la.pdf
- Використано для: Аміачна селітра

## acron-an
- **Ammonium nitrate, agricultural grade — product specification**
- Acron · Специфікація виробника/продавця
- https://market.acron.ru/upload/iblock/351/eebb2ozln0dw4sdsewcxaeeihg8fr9my.pdf
- Використано для: Аміачна селітра

## usda-nrcs-an
- **Ammonium Nitrate (nitrogen source fact sheet)**
- USDA NRCS (Arizona eFOTG) · Установа
- https://efotg.sc.egov.usda.gov/references/Public/AZ/Ammonium_Nitrate.pdf
- Використано для: Аміачна селітра

## cru-nitrate
- **High performance nitrate based fertilizers (CRU Insight, 31 July 2021)**
- CRU Group · Галузева аналітика
- https://bcinsight.crugroup.com/2021/07/31/high-performance-nitrate-based-fertilizers
- Використано для: Аміачна селітра

## wisc-phosphorus
- **Soil Science 326 — Essential Elements for Plant Growth: phosphorus fertilizers**
- University of Wisconsin–Madison, Soil Science · Навчальні матеріали
- https://soilsfacstaff.cals.wisc.edu/facstaff/barak/soilscience326/phosphorus.htm
- Використано для: Суперфосфат простий, Суперфосфат подвійний, Преципітат, Фосфоритне борошно

## fao-bulletin13
- **Use of phosphate rocks for sustainable agriculture (FAO Fertilizer and Plant Nutrition Bulletin 13, 2004)**
- FAO · Установа
- https://www.fao.org/4/y5053e/y5053e0a.htm
- Використано для: Фосфоритне борошно

## isij-slag
- **ISIJ International 54(12): citric acid solubility of phosphorus in P-bearing steelmaking slag used as slag phosphate fertilizer**
- ISIJ International (J-STAGE) · Наукова публікація
- https://www.jstage.jst.go.jp/article/isijinternational/54/12/54_2746/_html/-char/en
- Використано для: Томасшлак, Мартенівський фосфатшлак
- Примітка: Назву подано за змістом знайденого фрагмента; точну назву статті не підтверджено.

## echa-eu-fert
- **EU fertilisers list, Annex I A: “Basic slag — Thomas phosphates — Thomas slag”**
- ECHA (European Chemicals Agency) · Нормативний документ
- https://echa.europa.eu/bg/fertilizer-list-ann-1-a-e-1/-/legislationlist/details/EU-FERTILISERS-ANX_I_A_B_C_D_E1_E2_4_G_II-100.300.974-VSK-8B0E7F
- Використано для: Томасшлак

## msstate-k
- **Potassium sources (cotton production)**
- Mississippi State University Extension · Extension-служба університету
- https://extension.msstate.edu/agriculture/crops/cotton/potassium-sources
- Використано для: Сильвініт, Хлорид калію, Сульфат калію

## cornell-k
- **Certified Crop Adviser study resource: potassium sources (PO 28)**
- Cornell University (NRCCA) · Навчальні матеріали
- https://nrcca.cals.cornell.edu/nutrient/CA4/CA0428.php
- Використано для: Хлорид калію

## apni-k
- **Potassium sources and fertilizer properties (presentation, file Mikkelsen01.pdf)**
- APNI (apni.net) · Навчальні матеріали
- https://www.apni.net/wp-content/uploads/2020/05/Mikkelsen01.pdf
- Використано для: Каїніт, Сульфат калію, правило сумісності: kcl-k2so4-solution

## va-dcr
- **Commercial Fertilizer (Mid-Atlantic Nutrient Management Handbook, ch. 8; presentation)**
- Virginia Department of Conservation and Recreation · Установа
- https://www.dcr.virginia.gov/soil-and-water/document/Commercial-Fertilizer.pdf
- Використано для: Сульфат амонію, Суперфосфат подвійний, Хлорид калію, Сульфат калію, Діамонійфосфат (DAP)

## ks-patentkali
- **Patentkali leaflet: 30 % K₂O · 10 % MgO · 42.5 % SO₃ (= 17 % S)**
- K+S Minerals and Agriculture · Специфікація виробника/продавця
- https://www.kpluss.com/.downloads/agriculture-brochures/hu-patentkali-leaflet.pdf
- Використано для: Калімагнезія

## haifa-mkp
- **Haifa MKP™ — Monopotassium phosphate 0-52-34, product page (solubility 0–40 °C)**
- Haifa Group · Специфікація виробника/продавця
- https://www.haifa-group.com/haifa-mkp™-mono-potassium-phosphate-0-52-34
- Використано для: Монокалійфосфат, правило сумісності: ca-nitrate-phosphate-solution

## uralchem-npk
- **Nitroammophoska NPK 16:16:16 — product specification**
- UralChem · Специфікація виробника/продавця
- https://agro.uralchem.com/catalog/fertilizers/nitroammofoska-npk-16-16-16/
- Використано для: Нітроамофоска

## incitec-blends
- **Fact Sheet — Blends (fertiliser compatibility)**
- Incitec Pivot Fertilisers (Australia) · Специфікація виробника/продавця
- https://www.incitecpivotfertilisers.com.au:443/~/media/Files/IPF/Documents/Fact%20Sheets/38%20Blends%20Fact%20Sheet.pdf
- Використано для: правило сумісності: urea-an-dry

## ravensdown-urea
- **Urea — product page (blending compatibility)**
- Ravensdown (New Zealand) · Специфікація виробника/продавця
- https://www.ravensdown.co.nz/products/fertiliser/urea
- Використано для: правило сумісності: urea-limestone, правило сумісності: urea-ssp, правило сумісності: urea-tsp, правило сумісності: urea-kcl, правило сумісності: urea-calcium-nitrate

## yara-physical
- **Physical Properties of Fertilizers (compatibility notes, citing EFMA guidance)**
- Yara Canada · Специфікація виробника/продавця
- https://yaracanada.ca/crop-nutrition/fertilizer-handling-and-safety/physical-properties-of-fertilizers
- Використано для: правило сумісності: urea-ssp, правило сумісності: urea-ammonium-phosphates

## eagri-lec15
- **SSAC222, lecture 15: fertilizer mixtures (mixing and storage rules)**
- e-Agri course materials (eagriorg.github.io) · Навчальні матеріали
- https://eagriorg.github.io/eagri50/SSAC222/lec15.pdf
- Використано для: правило сумісності: an-quicklime, правило сумісності: an-slaked-lime, правило сумісності: ammonium-slag, правило сумісності: ammonium-strong-alkaline, правило сумісності: an-limestone, правило сумісності: as-limestone, правило сумісності: ammonium-mild-alkaline, правило сумісності: urea-ssp, правило сумісності: urea-tsp, правило сумісності: urea-kcl
- Примітка: Лекційний конспект; автора й установи не вдалося визначити.

## fe-guidance
- **Guidance for compatibility of fertilizer blending materials (issue 2014)**
- Fertilizers Europe · Галузева аналітика
- https://www.fertilizerseurope.com/wp-content/uploads/2019/08/Guidance_for_compatibility2.pdf
- Використано для: —
- Примітка: Знайдено лише вступ: не всі матеріали сумісні між собою; деталі конкретних пар не переглядалися.

